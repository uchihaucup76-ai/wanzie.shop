import { createClient } from "@/lib/supabase/server";
import { formatRupiah, timeAgo } from "@/lib/utils";

export default async function RiwayatPage() {
  const supabase = createClient();
  const { data: orders } = await supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false });

  const statusStyle: Record<string, string> = {
    pending: "bg-warn/10 text-warn",
    received: "bg-signal2/10 text-signal2",
    completed: "bg-signal/10 text-signal",
    canceled: "bg-danger/10 text-danger",
    expiring: "bg-danger/10 text-danger",
  };

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Riwayat Order</h1>

      {!orders || orders.length === 0 ? (
        <div className="card text-center text-sm text-muted">Belum ada riwayat order.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line text-xs uppercase tracking-wide text-muted">
                <th className="py-3 pr-4">Nomor</th>
                <th className="py-3 pr-4">Layanan</th>
                <th className="py-3 pr-4">Harga</th>
                <th className="py-3 pr-4">Status</th>
                <th className="py-3 pr-4">Waktu</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="border-b border-line/50">
                  <td className="py-3 pr-4 font-mono">{order.phone_number}</td>
                  <td className="py-3 pr-4">
                    {order.service_name}
                    <span className="block text-xs text-muted">{order.country_name}</span>
                  </td>
                  <td className="py-3 pr-4 font-mono">{formatRupiah(order.sell_price)}</td>
                  <td className="py-3 pr-4">
                    <span className={`status-pill ${statusStyle[order.status] || "bg-muted/10 text-muted"}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="py-3 pr-4 text-muted">{timeAgo(order.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
