"use client";

import { useEffect, useState } from "react";
import { formatRupiah } from "@/lib/utils";

type Service = { service_code: number; service_name: string; service_img: string };
type PricelistItem = {
  provider_id: string;
  server_id: number;
  stock: number;
  sell_price: number;
  available: boolean;
};
type Country = {
  number_id: number;
  name: string;
  img: string;
  stock_total: number;
  pricelist: PricelistItem[];
};
type Operator = { id: number; name: string; image: string };

type ActiveOrder = {
  id: string;
  phone_number: string;
  status: string;
  otp_code: string | null;
  otp_message: string | null;
  sell_price: number;
};

export default function BeliNomorPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);

  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [selectedPricelist, setSelectedPricelist] = useState<PricelistItem | null>(null);
  const [selectedOperator, setSelectedOperator] = useState<Operator | null>(null);

  const [loadingStep, setLoadingStep] = useState<string | null>("services");
  const [buying, setBuying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const [activeOrder, setActiveOrder] = useState<ActiveOrder | null>(null);

  useEffect(() => {
    fetch("/api/rumahotp/services")
      .then((res) => res.json())
      .then((res) => {
        if (res.error) throw new Error(res.error);
        setServices(res.data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoadingStep(null));
  }, []);

  function selectService(service: Service) {
    setSelectedService(service);
    setSelectedCountry(null);
    setSelectedPricelist(null);
    setSelectedOperator(null);
    setCountries([]);
    setLoadingStep("countries");
    setError(null);

    fetch(`/api/rumahotp/countries?service_id=${service.service_code}`)
      .then((res) => res.json())
      .then((res) => {
        if (res.error) throw new Error(res.error);
        setCountries(res.data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoadingStep(null));
  }

  function selectPricelist(country: Country, item: PricelistItem) {
    setSelectedCountry(country);
    setSelectedPricelist(item);
    setSelectedOperator(null);
    setOperators([]);
    setLoadingStep("operators");
    setError(null);

    fetch(`/api/rumahotp/operators?country=${encodeURIComponent(country.name)}&provider_id=${item.provider_id}`)
      .then((res) => res.json())
      .then((res) => {
        if (res.error) throw new Error(res.error);
        setOperators(res.data.length ? res.data : [{ id: 0, name: "Operator apa saja", image: "" }]);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoadingStep(null));
  }

  async function handleBuy() {
    if (!selectedService || !selectedCountry || !selectedPricelist || !selectedOperator) return;

    setBuying(true);
    setError(null);

    try {
      const res = await fetch("/api/rumahotp/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          number_id: selectedCountry.number_id,
          provider_id: selectedPricelist.provider_id,
          operator_id: selectedOperator.id,
          service_name: selectedService.service_name,
          country_name: selectedCountry.name,
          operator_name: selectedOperator.name,
        }),
      });
      const json = await res.json();
      if (json.error) throw new Error(json.error);

      setActiveOrder(json.data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBuying(false);
    }
  }

  // Poll status tiap 5 detik selama order masih pending/received
  useEffect(() => {
    if (!activeOrder || ["completed", "canceled"].includes(activeOrder.status)) return;

    const interval = setInterval(async () => {
      const res = await fetch(`/api/rumahotp/status?id=${activeOrder.id}`);
      const json = await res.json();
      if (json.data) setActiveOrder(json.data);
    }, 5000);

    return () => clearInterval(interval);
  }, [activeOrder]);

  async function handleOrderAction(action: "cancel" | "done" | "resend") {
    if (!activeOrder) return;
    const res = await fetch("/api/rumahotp/set-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: activeOrder.id, action }),
    });
    const json = await res.json();
    if (json.data) setActiveOrder(json.data);
  }

  function resetFlow() {
    setActiveOrder(null);
    setSelectedService(null);
    setSelectedCountry(null);
    setSelectedPricelist(null);
    setSelectedOperator(null);
  }

  const filteredServices = services.filter((s) =>
    s.service_name.toLowerCase().includes(search.toLowerCase())
  );

  // ------- Tampilan order aktif (menunggu / menerima OTP) -------
  if (activeOrder) {
    return (
      <div className="mx-auto max-w-md">
        <div className="card text-center">
          <p className="text-sm text-muted">Nomor kamu</p>
          <p className="mt-2 font-mono text-2xl font-bold text-signal">{activeOrder.phone_number}</p>

          <div className="mt-6">
            {activeOrder.otp_code ? (
              <div>
                <p className="text-sm text-muted">Kode OTP diterima</p>
                <div className="mt-2 flex justify-center gap-2">
                  {activeOrder.otp_code.split("").map((digit, i) => (
                    <div key={i} className="digit-box">
                      {digit}
                    </div>
                  ))}
                </div>
                {activeOrder.otp_message && (
                  <p className="mt-3 text-xs text-muted">{activeOrder.otp_message}</p>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 py-4">
                <span className="h-3 w-3 animate-pulse rounded-full bg-warn" />
                <p className="text-sm text-muted">Menunggu SMS masuk…</p>
              </div>
            )}
          </div>

          <div className="mt-6 flex justify-center gap-3">
            {!activeOrder.otp_code && activeOrder.status === "pending" && (
              <button onClick={() => handleOrderAction("cancel")} className="btn-secondary text-sm">
                Batalkan &amp; refund
              </button>
            )}
            {activeOrder.otp_code && (
              <button onClick={() => handleOrderAction("resend")} className="btn-secondary text-sm">
                Minta kode lagi
              </button>
            )}
            <button onClick={resetFlow} className="btn-primary text-sm">
              Beli nomor lain
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Beli Nomor Virtual</h1>

      {error && (
        <p className="rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-danger">
          {error}
        </p>
      )}

      {/* Step 1: pilih service */}
      <div>
        <h2 className="mb-3 text-sm font-semibold text-muted">1. Pilih aplikasi</h2>
        <input
          type="text"
          placeholder="Cari aplikasi…"
          className="input-field mb-3"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {loadingStep === "services" ? (
          <p className="text-sm text-muted">Memuat daftar aplikasi…</p>
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {filteredServices.slice(0, 24).map((service) => (
              <button
                key={service.service_code}
                onClick={() => selectService(service)}
                className={`rounded-md border px-3 py-2 text-left text-sm transition ${
                  selectedService?.service_code === service.service_code
                    ? "border-signal text-signal"
                    : "border-line hover:border-signal/50"
                }`}
              >
                {service.service_name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Step 2: pilih negara + harga */}
      {selectedService && (
        <div>
          <h2 className="mb-3 text-sm font-semibold text-muted">2. Pilih negara</h2>
          {loadingStep === "countries" ? (
            <p className="text-sm text-muted">Memuat daftar negara…</p>
          ) : (
            <div className="space-y-2">
              {countries.map((country) =>
                country.pricelist
                  .filter((p) => p.available)
                  .map((item) => (
                    <button
                      key={`${country.number_id}-${item.provider_id}`}
                      onClick={() => selectPricelist(country, item)}
                      className={`flex w-full items-center justify-between rounded-md border px-4 py-3 text-left text-sm transition ${
                        selectedPricelist?.provider_id === item.provider_id &&
                        selectedCountry?.number_id === country.number_id
                          ? "border-signal text-signal"
                          : "border-line hover:border-signal/50"
                      }`}
                    >
                      <span>
                        {country.name}{" "}
                        <span className="text-xs text-muted">(stok {item.stock})</span>
                      </span>
                      <span className="font-mono">{formatRupiah(item.sell_price)}</span>
                    </button>
                  ))
              )}
            </div>
          )}
        </div>
      )}

      {/* Step 3: pilih operator */}
      {selectedCountry && selectedPricelist && (
        <div>
          <h2 className="mb-3 text-sm font-semibold text-muted">3. Pilih operator</h2>
          {loadingStep === "operators" ? (
            <p className="text-sm text-muted">Memuat daftar operator…</p>
          ) : (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {operators.map((op) => (
                <button
                  key={op.id}
                  onClick={() => setSelectedOperator(op)}
                  className={`rounded-md border px-3 py-2 text-sm transition ${
                    selectedOperator?.id === op.id
                      ? "border-signal text-signal"
                      : "border-line hover:border-signal/50"
                  }`}
                >
                  {op.name}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 4: konfirmasi beli */}
      {selectedOperator && selectedPricelist && (
        <div className="card flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-muted">Total bayar</p>
            <p className="font-mono text-xl font-bold text-signal">
              {formatRupiah(selectedPricelist.sell_price)}
            </p>
          </div>
          <button onClick={handleBuy} disabled={buying} className="btn-primary">
            {buying ? "Memproses…" : "Beli Nomor Sekarang"}
          </button>
        </div>
      )}
    </div>
  );
}
