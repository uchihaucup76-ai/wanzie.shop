import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatRupiah, timeAgo } from "@/lib/utils";

export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("balance")
    .eq("id", user!.id)
    .single();

  const { data: recentOrders } = await supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5);

  const statusStyle: Record<string, string> = {
    pending: "bg-warn/10 text-warn",
    received: "bg-signal2/10 text-signal2",
    completed: "bg-signal/10 text-signal",
    canceled: "bg-danger/10 text-danger",
    expiring: "bg-danger/10 text-danger",
  };

  return (
    <div className="space-y-8">
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="card sm:col-span-2">
          <p className="text-sm text-muted">Saldo kamu</p>
          <p className="mt-2 font-mono text-3xl font-bold text-signal">
            {formatRupiah(profile?.balance ?? 0)}
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link href="/dashboard/topup" className="btn-primary text-sm">
              Top Up Saldo
            </Link>
            <Link href="/dashboard/beli" className="btn-secondary text-sm">
              Beli Nomor
            </Link>
          </div>
        </div>

        <div className="card flex flex-col justify-center">
          <p className="text-sm text-muted">Butuh bantuan?</p>
          <p className="mt-2 text-sm">
            Pastikan aplikasi tujuan belum pernah didaftarkan dengan nomor yang sama sebelumnya.
          </p>
        </div>
      </div>

      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Order terbaru</h2>
          <Link href="/dashboard/riwayat" className="text-sm text-signal hover:underline">
            Lihat semua
          </Link>
        </div>

        {!recentOrders || recentOrders.length === 0 ? (
          <div className="card text-center text-sm text-muted">
            Belum ada order. <Link href="/dashboard/beli" className="text-signal hover:underline">Beli nomor pertama kamu.</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {recentOrders.map((order) => (
              <div key={order.id} className="card flex items-center justify-between">
                <div>
                  <p className="font-mono text-sm">{order.phone_number}</p>
                  <p className="mt-1 text-xs text-muted">
                    {order.service_name} · {order.country_name} · {timeAgo(order.created_at)}
                  </p>
                </div>
                <span className={`status-pill ${statusStyle[order.status] || "bg-muted/10 text-muted"}`}>
                  {order.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
