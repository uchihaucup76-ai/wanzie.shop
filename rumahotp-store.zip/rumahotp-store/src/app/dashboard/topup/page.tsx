"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { formatRupiah } from "@/lib/utils";

type Deposit = {
  id: string;
  amount_requested: number;
  status: string;
  qr_string: string;
  qr_image: string;
  expired_at: string;
};

const presets = [10000, 25000, 50000, 100000, 250000];

export default function TopupPage() {
  const [amount, setAmount] = useState(50000);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deposit, setDeposit] = useState<Deposit | null>(null);

  async function handleCreate() {
    setCreating(true);
    setError(null);

    try {
      const res = await fetch("/api/deposit/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
      });
      const json = await res.json();
      if (json.error) throw new Error(json.error);
      setDeposit(json.data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCreating(false);
    }
  }

  useEffect(() => {
    if (!deposit || deposit.status !== "pending") return;

    const interval = setInterval(async () => {
      const res = await fetch(`/api/deposit/status?id=${deposit.id}`);
      const json = await res.json();
      if (json.data) setDeposit(json.data);
    }, 4000);

    return () => clearInterval(interval);
  }, [deposit]);

  if (deposit) {
    return (
      <div className="mx-auto max-w-sm">
        <div className="card text-center">
          {deposit.status === "success" ? (
            <div>
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-signal/10 text-signal">
                ✓
              </div>
              <p className="mt-4 font-semibold text-signal">Top up berhasil</p>
              <p className="mt-1 text-sm text-muted">
                Saldo {formatRupiah(deposit.amount_requested)} sudah masuk ke akun kamu.
              </p>
              <a href="/dashboard" className="btn-primary mt-6 inline-flex">
                Kembali ke dashboard
              </a>
            </div>
          ) : (
            <div>
              <p className="text-sm text-muted">Scan buat bayar</p>
              <p className="mt-1 font-mono text-xl font-bold text-signal">
                {formatRupiah(deposit.amount_requested)}
              </p>

              {deposit.qr_image ? (
                <div className="mx-auto mt-4 w-56 overflow-hidden rounded-md border border-line bg-white p-2">
                  <Image
                    src={deposit.qr_image}
                    alt="QRIS"
                    width={220}
                    height={220}
                    className="h-auto w-full"
                    unoptimized
                  />
                </div>
              ) : (
                <p className="mt-4 break-all font-mono text-xs text-muted">{deposit.qr_string}</p>
              )}

              <div className="mt-4 flex items-center justify-center gap-2 text-sm text-muted">
                <span className="h-2 w-2 animate-pulse rounded-full bg-warn" />
                Menunggu pembayaran…
              </div>

              <button onClick={() => setDeposit(null)} className="btn-secondary mt-6 text-sm">
                Batal, ganti nominal
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Top Up Saldo</h1>

      <div className="card space-y-4">
        <div>
          <label className="mb-2 block text-sm text-muted">Pilih nominal</label>
          <div className="grid grid-cols-3 gap-2">
            {presets.map((preset) => (
              <button
                key={preset}
                onClick={() => setAmount(preset)}
                className={`rounded-md border px-3 py-2 text-sm transition ${
                  amount === preset ? "border-signal text-signal" : "border-line hover:border-signal/50"
                }`}
              >
                {formatRupiah(preset)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm text-muted">Atau nominal lain (min. Rp10.000)</label>
          <input
            type="number"
            min={10000}
            step={1000}
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="input-field"
          />
        </div>

        {error && (
          <p className="rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-danger">
            {error}
          </p>
        )}

        <button onClick={handleCreate} disabled={creating || amount < 10000} className="btn-primary w-full">
          {creating ? "Membuat QRIS…" : "Buat Kode QRIS"}
        </button>
      </div>
    </div>
  );
}
