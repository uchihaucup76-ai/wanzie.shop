import Link from "next/link";

const apps = ["WhatsApp", "Telegram", "Instagram", "TikTok", "Facebook", "Gmail", "Tinder", "Discord"];

const steps = [
  {
    label: "Pilih aplikasi & negara",
    text: "Cari WhatsApp, Telegram, atau ratusan aplikasi lain, lalu pilih negara nomornya.",
  },
  {
    label: "Bayar dari saldo",
    text: "Top up sekali pakai QRIS, saldo bisa dipakai berkali-kali buat beli nomor.",
  },
  {
    label: "Terima kode OTP",
    text: "Nomor & kode verifikasi muncul otomatis di dashboard, biasanya dalam hitungan detik.",
  },
];

export default function LandingPage() {
  return (
    <main>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="font-display text-lg font-bold tracking-tight">
          signal<span className="text-signal">.</span>
        </span>
        <nav className="flex items-center gap-3">
          <Link href="/login" className="text-sm text-muted hover:text-paper">
            Masuk
          </Link>
          <Link href="/register" className="btn-primary text-sm">
            Daftar Gratis
          </Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="mx-auto flex max-w-6xl flex-col items-center px-6 pb-20 pt-12 text-center sm:pt-20">
        <span className="status-pill border border-line bg-panel text-signal">
          <span className="h-1.5 w-1.5 rounded-full bg-signal" />
          85+ negara &middot; 1.700+ aplikasi
        </span>

        <h1 className="mt-6 max-w-3xl text-4xl font-bold leading-tight sm:text-6xl">
          Nomor virtual untuk verifikasi apa saja,
          <span className="text-signal"> masuk dalam hitungan detik.</span>
        </h1>

        <p className="mt-5 max-w-xl text-muted">
          Beli nomor sekali pakai buat WhatsApp, Telegram, dan ribuan aplikasi lain. Gak perlu
          nomor pribadi, gak perlu SIM card baru.
        </p>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link href="/register" className="btn-primary">
            Mulai Beli Nomor
          </Link>
          <Link href="/login" className="btn-secondary">
            Saya sudah punya akun
          </Link>
        </div>

        {/* Signature element: simulasi OTP masuk */}
        <div className="mt-16 flex flex-col items-center gap-3">
          <span className="font-mono text-xs uppercase tracking-widest text-muted">
            kode verifikasi diterima
          </span>
          <div className="flex gap-2">
            {["8", "4", "1", "0", "2", "6"].map((digit, i) => (
              <div key={i} className="digit-box">
                {digit}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Apps */}
      <section className="border-y border-line bg-panel/40 py-10">
        <div className="mx-auto max-w-6xl px-6">
          <p className="text-center text-xs uppercase tracking-widest text-muted">
            Mendukung ribuan aplikasi, termasuk
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-muted">
            {apps.map((app) => (
              <span key={app}>{app}</span>
            ))}
            <span>+ 1.700 lainnya</span>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="text-2xl font-bold sm:text-3xl">Cara kerjanya</h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-3">
          {steps.map((step, i) => (
            <div key={step.label} className="card">
              <span className="font-mono text-sm text-signal">0{i + 1}</span>
              <h3 className="mt-3 font-semibold">{step.label}</h3>
              <p className="mt-2 text-sm text-muted">{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-line px-6 py-8 text-center text-xs text-muted">
        Dijalankan dengan integrasi API RumahOTP. Bukan situs resmi RumahOTP.
      </footer>
    </main>
  );
}
