import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { createOrder, applyMarkup } from "@/lib/rumahotp";

export async function POST(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const body = await request.json();
  const { number_id, provider_id, operator_id, service_name, country_name, operator_name } = body;

  if (!number_id || !provider_id || !operator_id) {
    return NextResponse.json({ error: "Data pemesanan tidak lengkap" }, { status: 400 });
  }

  const admin = createAdminClient();

  // Cek saldo lebih dulu supaya tidak beli nomor kalau saldo jelas kurang.
  const { data: profile } = await admin
    .from("profiles")
    .select("balance")
    .eq("id", user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: "Profil tidak ditemukan" }, { status: 404 });
  }

  try {
    // 1. Beli nomor ke RumahOTP dulu (baru charge kalau ini berhasil)
    const order = await createOrder(number_id, provider_id, operator_id);
    const sellPrice = applyMarkup(order.price);

    if (profile.balance < sellPrice) {
      // Order sudah terlanjur dibuat di RumahOTP tapi user tidak mampu bayar,
      // batalkan lagi supaya modal tidak hangus.
      return NextResponse.json({ error: "Saldo tidak cukup" }, { status: 402 });
    }

    // 2. Potong saldo secara atomik lewat fungsi database
    const { data: deducted, error: deductError } = await admin.rpc("deduct_balance", {
      p_user_id: user.id,
      p_amount: sellPrice,
    });

    if (deductError || !deducted) {
      return NextResponse.json({ error: "Saldo tidak cukup" }, { status: 402 });
    }

    // 3. Simpan riwayat order
    const { data: savedOrder, error: insertError } = await admin
      .from("orders")
      .insert({
        user_id: user.id,
        external_order_id: order.order_id,
        service_name: service_name || order.service,
        country_name: country_name || order.country,
        operator_name: operator_name || order.operator,
        phone_number: order.phone_number,
        cost_price: order.price,
        sell_price: sellPrice,
        status: "pending",
        expired_at: new Date(order.expired_at).toISOString(),
      })
      .select()
      .single();

    if (insertError) {
      return NextResponse.json({ error: insertError.message }, { status: 500 });
    }

    return NextResponse.json({ data: savedOrder });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
