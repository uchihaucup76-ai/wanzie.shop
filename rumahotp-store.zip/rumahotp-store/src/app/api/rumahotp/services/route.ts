import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getServices } from "@/lib/rumahotp";

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  try {
    const services = await getServices();
    return NextResponse.json({ data: services });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
