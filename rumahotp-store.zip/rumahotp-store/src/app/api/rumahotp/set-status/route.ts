import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { setOrderStatus } from "@/lib/rumahotp";

export async function POST(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const body = await request.json();
  const { id, action } = body; // id = baris order kita, action = 'cancel' | 'done' | 'resend'

  if (!id || !["cancel", "done", "resend"].includes(action)) {
    return NextResponse.json({ error: "Parameter tidak valid" }, { status: 400 });
  }

  const admin = createAdminClient();

  const { data: existing } = await admin
    .from("orders")
    .select("*")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (!existing) {
    return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  }

  try {
    await setOrderStatus(existing.external_order_id, action);

    let newStatus = existing.status;
    if (action === "cancel") newStatus = "canceled";
    if (action === "done") newStatus = "completed";

    const { data: updated } = await admin
      .from("orders")
      .update({ status: newStatus })
      .eq("id", id)
      .select()
      .single();

    // Refund otomatis kalau dibatalkan dan sebelumnya belum berstatus batal.
    if (action === "cancel" && existing.status !== "canceled") {
      await admin.rpc("add_balance", { p_user_id: user.id, p_amount: existing.sell_price });
    }

    return NextResponse.json({ data: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
