import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { checkOrderStatus } from "@/lib/rumahotp";

export async function GET(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const orderRowId = searchParams.get("id"); // id baris di tabel orders kita

  if (!orderRowId) {
    return NextResponse.json({ error: "id wajib diisi" }, { status: 400 });
  }

  const admin = createAdminClient();

  const { data: existing } = await admin
    .from("orders")
    .select("*")
    .eq("id", orderRowId)
    .eq("user_id", user.id)
    .single();

  if (!existing) {
    return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  }

  // Kalau sudah final, tidak perlu tanya ke RumahOTP lagi.
  if (["completed", "canceled"].includes(existing.status)) {
    return NextResponse.json({ data: existing });
  }

  try {
    const status = await checkOrderStatus(existing.external_order_id);

    if (status.status !== existing.status || status.otp_code) {
      const { data: updated } = await admin
        .from("orders")
        .update({
          status: status.status,
          otp_code: status.otp_code || existing.otp_code,
          otp_message: status.otp_msg || existing.otp_message,
        })
        .eq("id", orderRowId)
        .select()
        .single();

      return NextResponse.json({ data: updated });
    }

    return NextResponse.json({ data: existing });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
