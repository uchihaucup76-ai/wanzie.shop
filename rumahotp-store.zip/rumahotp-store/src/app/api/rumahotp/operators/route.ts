import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getOperators } from "@/lib/rumahotp";

export async function GET(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const country = searchParams.get("country");
  const providerId = searchParams.get("provider_id");

  if (!country || !providerId) {
    return NextResponse.json({ error: "country dan provider_id wajib diisi" }, { status: 400 });
  }

  try {
    const operators = await getOperators(country, providerId);
    return NextResponse.json({ data: operators });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
