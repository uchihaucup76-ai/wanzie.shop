import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getCountries, applyMarkup } from "@/lib/rumahotp";

export async function GET(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const serviceId = searchParams.get("service_id");

  if (!serviceId) {
    return NextResponse.json({ error: "service_id wajib diisi" }, { status: 400 });
  }

  try {
    const countries = await getCountries(serviceId);

    // Terapkan markup harga jual, jangan bocorkan harga modal asli ke client.
    const withMarkup = countries.map((country) => ({
      ...country,
      pricelist: country.pricelist.map((item) => ({
        ...item,
        sell_price: applyMarkup(item.price),
      })),
    }));

    return NextResponse.json({ data: withMarkup });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
