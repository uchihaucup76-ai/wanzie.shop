import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { checkDepositStatus } from "@/lib/rumahotp";

export async function GET(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const rowId = searchParams.get("id");

  if (!rowId) {
    return NextResponse.json({ error: "id wajib diisi" }, { status: 400 });
  }

  const admin = createAdminClient();

  const { data: existing } = await admin
    .from("deposits")
    .select("*")
    .eq("id", rowId)
    .eq("user_id", user.id)
    .single();

  if (!existing) {
    return NextResponse.json({ error: "Deposit tidak ditemukan" }, { status: 404 });
  }

  // Sudah final sebelumnya, tidak perlu tambah saldo lagi (mencegah double credit).
  if (existing.status === "success" || existing.status === "cancel") {
    return NextResponse.json({ data: existing });
  }

  try {
    const status = await checkDepositStatus(existing.external_deposit_id);

    if (status.status !== existing.status) {
      const { data: updated } = await admin
        .from("deposits")
        .update({ status: status.status })
        .eq("id", rowId)
        .select()
        .single();

      // Baru sukses sekarang -> tambahkan saldo user, sekali saja.
      if (status.status === "success") {
        await admin.rpc("add_balance", {
          p_user_id: user.id,
          p_amount: existing.amount_received,
        });
      }

      return NextResponse.json({ data: updated });
    }

    return NextResponse.json({ data: existing });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
