import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { createDeposit } from "@/lib/rumahotp";

const MIN_DEPOSIT = 10000;

export async function POST(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Belum login" }, { status: 401 });
  }

  const body = await request.json();
  const amount = Number(body.amount);

  if (!amount || amount < MIN_DEPOSIT) {
    return NextResponse.json(
      { error: `Minimal top up ${MIN_DEPOSIT.toLocaleString("id-ID")}` },
      { status: 400 }
    );
  }

  try {
    const deposit = await createDeposit(amount);
    const admin = createAdminClient();

    const { data: saved, error } = await admin
      .from("deposits")
      .insert({
        user_id: user.id,
        external_deposit_id: deposit.id,
        amount_requested: amount,
        amount_received: deposit.currency?.diterima ?? amount,
        fee: deposit.currency?.fee ?? 0,
        method: "qris",
        status: "pending",
        qr_string: deposit.qr_string,
        qr_image: deposit.qr_image,
        expired_at: new Date(deposit.expired).toISOString(),
      })
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ data: saved });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
