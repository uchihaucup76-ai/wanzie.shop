import Link from "next/link";
import { formatRupiah } from "@/lib/utils";
import LogoutButton from "./LogoutButton";

const links = [
  { href: "/dashboard", label: "Ringkasan" },
  { href: "/dashboard/beli", label: "Beli Nomor" },
  { href: "/dashboard/riwayat", label: "Riwayat" },
  { href: "/dashboard/topup", label: "Top Up" },
];

export default function Navbar({ balance }: { balance: number }) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-8">
          <Link href="/dashboard" className="font-display text-lg font-bold">
            signal<span className="text-signal">.</span>
          </Link>
          <nav className="hidden gap-6 sm:flex">
            {links.map((link) => (
              <Link key={link.href} href={link.href} className="text-sm text-muted hover:text-paper">
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <Link
            href="/dashboard/topup"
            className="rounded-md border border-line bg-panel px-3 py-1.5 font-mono text-sm text-signal hover:border-signal/50"
          >
            {formatRupiah(balance)}
          </Link>
          <LogoutButton />
        </div>
      </div>
      <nav className="flex gap-4 overflow-x-auto border-t border-line px-6 py-2 sm:hidden">
        {links.map((link) => (
          <Link key={link.href} href={link.href} className="whitespace-nowrap text-sm text-muted">
            {link.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
