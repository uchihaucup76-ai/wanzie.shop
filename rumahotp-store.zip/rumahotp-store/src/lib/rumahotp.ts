// Wrapper ini HANYA boleh dipanggil dari Route Handler (server),
// karena butuh RUMAHOTP_API_KEY yang harus tetap rahasia.

const BASE_URL = process.env.RUMAHOTP_BASE_URL || "https://www.rumahotp.io/api";

async function rumahotpFetch<T = any>(path: string, params: Record<string, string | number> = {}) {
  const url = new URL(`${BASE_URL}${path}`);
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.set(key, String(value));
  });

  const res = await fetch(url.toString(), {
    method: "GET",
    headers: {
      "x-apikey": process.env.RUMAHOTP_API_KEY || "",
      Accept: "application/json",
    },
    cache: "no-store",
  });

  const json = await res.json();

  if (!json.success) {
    throw new Error(json?.error?.message || "Permintaan ke RumahOTP gagal");
  }

  return json.data as T;
}

export type RumahOTPService = {
  service_code: number;
  service_name: string;
  service_img: string;
};

export function getServices() {
  return rumahotpFetch<RumahOTPService[]>("/v2/services");
}

export type RumahOTPPricelistItem = {
  provider_id: string;
  server_id: number;
  stock: number;
  rate: number;
  price: number;
  price_format: string;
  available: boolean;
};

export type RumahOTPCountry = {
  number_id: number;
  name: string;
  img: string;
  prefix: string;
  iso_code: string;
  rate: number;
  stock_total: number;
  pricelist: RumahOTPPricelistItem[];
};

export function getCountries(serviceId: number | string) {
  return rumahotpFetch<RumahOTPCountry[]>("/v2/countries", { service_id: serviceId });
}

export type RumahOTPOperator = {
  id: number;
  name: string;
  image: string;
};

export function getOperators(country: string, providerId: number | string) {
  return rumahotpFetch<RumahOTPOperator[]>("/v2/operators", { country, provider_id: providerId });
}

export type RumahOTPOrder = {
  order_id: string;
  phone_number: string;
  service: string;
  country: string;
  operator: string;
  price: number;
  price_formated: string;
  created_at: number;
  expired_at: number;
};

export function createOrder(numberId: number | string, providerId: number | string, operatorId: number | string) {
  return rumahotpFetch<RumahOTPOrder>("/v2/orders", {
    number_id: numberId,
    provider_id: providerId,
    operator_id: operatorId,
  });
}

export type RumahOTPOrderStatus = {
  order_id: string;
  status: "received" | "completed" | "canceled" | "expiring";
  phone_number: string;
  service: string;
  country: string;
  created_at: number;
  expired_at: number;
  otp_code?: string;
  otp_msg?: string;
};

export function checkOrderStatus(orderId: string) {
  return rumahotpFetch<RumahOTPOrderStatus>("/v1/orders/get_status", { order_id: orderId });
}

export function setOrderStatus(orderId: string, status: "cancel" | "done" | "resend") {
  return rumahotpFetch("/v1/orders/set_status", { order_id: orderId, status });
}

export type RumahOTPDeposit = {
  id: string;
  method: string;
  amount: number;
  currency: { type: string; total: number; fee: number; diterima: number };
  qr_string: string;
  qr_image: string;
  created: number;
  expired: number;
};

export function createDeposit(amount: number) {
  return rumahotpFetch<RumahOTPDeposit>("/v1/deposit/create", { amount, payment_id: "qris" });
}

export type RumahOTPDepositStatus = {
  id: string;
  status: "success" | "pending" | "cancel";
  created: number;
  expired: number;
  amount: number;
};

export function checkDepositStatus(depositId: string) {
  return rumahotpFetch<RumahOTPDepositStatus>("/v1/deposit/get_status", { deposit_id: depositId });
}

// Markup harga jual ke user di atas harga modal RumahOTP.
export function applyMarkup(costPrice: number) {
  const percent = Number(process.env.NEXT_PUBLIC_MARKUP_PERCENT || "20");
  return Math.ceil(costPrice * (1 + percent / 100));
}
