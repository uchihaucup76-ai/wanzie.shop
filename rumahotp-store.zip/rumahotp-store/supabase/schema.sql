-- =========================================================
-- RumahOTP Store — Supabase schema
-- Jalankan seluruh file ini di: Supabase Dashboard > SQL Editor > New query
-- =========================================================

-- 1. Tabel profil user (menyimpan saldo)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  balance bigint not null default 0,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

-- 2. Tabel riwayat order nomor OTP
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  external_order_id text not null,
  service_name text not null,
  country_name text not null,
  operator_name text,
  phone_number text,
  cost_price bigint not null,
  sell_price bigint not null,
  status text not null default 'pending', -- pending, received, completed, canceled, expiring
  otp_code text,
  otp_message text,
  created_at timestamptz not null default now(),
  expired_at timestamptz
);

alter table public.orders enable row level security;

create policy "orders_select_own"
  on public.orders for select
  using (auth.uid() = user_id);

create index if not exists orders_user_id_idx on public.orders (user_id, created_at desc);

-- 3. Tabel riwayat deposit / top up saldo
create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  external_deposit_id text not null,
  amount_requested bigint not null,
  amount_received bigint,
  fee bigint,
  method text not null default 'qris',
  status text not null default 'pending', -- pending, success, cancel, expired
  qr_string text,
  qr_image text,
  created_at timestamptz not null default now(),
  expired_at timestamptz
);

alter table public.deposits enable row level security;

create policy "deposits_select_own"
  on public.deposits for select
  using (auth.uid() = user_id);

create index if not exists deposits_user_id_idx on public.deposits (user_id, created_at desc);

-- 4. Auto-buat baris profile saat user baru daftar
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, balance)
  values (new.id, new.email, 0);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 5. Fungsi kurangi saldo dengan aman (dipakai server, bukan langsung dari client)
create or replace function public.deduct_balance(p_user_id uuid, p_amount bigint)
returns boolean
language plpgsql
security definer set search_path = public
as $$
declare
  current_balance bigint;
begin
  select balance into current_balance from public.profiles where id = p_user_id for update;

  if current_balance is null or current_balance < p_amount then
    return false;
  end if;

  update public.profiles set balance = balance - p_amount where id = p_user_id;
  return true;
end;
$$;

-- 6. Fungsi tambah saldo dengan aman (dipakai server saat deposit sukses)
create or replace function public.add_balance(p_user_id uuid, p_amount bigint)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  update public.profiles set balance = balance + p_amount where id = p_user_id;
end;
$$;
